export type Movies = Movie[];

export type Movie = {
  Title: string;
  Year: number;
  Rated: string;
  Released: string;
  Runtime: string;
  Genre: string[];
  Director: string;
  Writer: string;
  Actors: string[];
  Plot: string;
  Language: string[];
  Country: string;
  Awards: string;
  Poster: string;
  Metascore: string;
  imdbRating: string;
  imdbVotes: string;
  imdbID: string;
  Type: string;
  Response: string;
  Images: string[];
  Id: string;
  Room: number;
  PlaysToday: boolean;
  totalSeasons?: string;
};
