import { Box, Typography } from "@mui/material";
import { ProgrammingObject } from "../data";
import { FC } from "react";

type ProgramItemProps = {
  item: ProgrammingObject;
};

export const ProgramItem: FC<ProgramItemProps> = ({ item }) => {
  return (
    <Box padding={1} display="flex" alignItems="baseline">
      <img alt="logo" src={item.logo} style={{ width: 30, paddingRight: 10 }} />
      <Typography
        variant="h4"
        flex={2}
        color={item.isProgrammingLanguage ? "black" : "red"}
      >
        {item.name}
      </Typography>
      <Typography variant="caption" flex={1}>
        {item.year}
      </Typography>
      <Typography flex={2} variant="h6">
        {item.creator}
      </Typography>
    </Box>
  );
};
