import { Box } from "@mui/system";
import { ProgramItem } from "./ProgramItem";
import { ProgrammingObject } from "../data";
import { FC } from "react";

type ProgramsProps = {
  items: ProgrammingObject[];
};

export const Programs: FC<ProgramsProps> = ({ items }) => {
  return (
    <Box width="50%">
      {items.map((item) => (
        <ProgramItem item={item} key={item.id} />
      ))}
    </Box>
  );
};
