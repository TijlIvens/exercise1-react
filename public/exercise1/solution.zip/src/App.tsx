import { Box } from "@mui/material";
import { FC } from "react";
import { Programs } from "./components/Programs";
import { PROGRAMMING_DATA } from "./data";

export const App: FC = () => {
  return (
    <Box padding={3}>
      <Programs items={PROGRAMMING_DATA} />
    </Box>
  );
};
