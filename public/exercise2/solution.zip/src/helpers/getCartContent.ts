export const getCartContent = () => {
  const cartString = localStorage.getItem("cart");

  const cartContent: { [key in string]: number } = cartString
    ? JSON.parse(cartString)
    : [];

  console.log(cartContent);

  return cartContent;
};

export const saveCartContent = (content: { [key in string]: number }) => {
  localStorage.setItem("cart", JSON.stringify(content));
};
