import { FC } from "react";
import {
  Box,
  Card,
  CardContent,
  CardMedia,
  IconButton,
  Typography,
} from "@mui/material";
import AddCircleIcon from "@mui/icons-material/AddCircle";
import RemoveCircleIcon from "@mui/icons-material/RemoveCircle";
import { Product } from "../../../constants/constants";

export interface ShoppingCartItemProps {
  item: Product & { amount: number };
  onIncreaseItem: () => void;
  onDecreaseItem: () => void;
}

export const ShoppingCartItem: FC<ShoppingCartItemProps> = ({
  item,
  onDecreaseItem,
  onIncreaseItem,
}) => {
  return (
    <Card sx={{ display: "flex", width: "100%" }}>
      <CardMedia
        component="img"
        sx={{ width: 200 }}
        image={item.image}
        alt={item.name}
      />
      <CardContent
        sx={{
          display: "flex",
          justifyContent: "space-between",
          width: "100%",
        }}
      >
        <Box display="flex" flexDirection="column" flexGrow={1}>
          <Typography variant="h3">{item.name}</Typography>
          <Typography>{item.description}</Typography>
        </Box>
        <Box display="flex" alignItems="center">
          <IconButton onClick={onDecreaseItem}>
            <RemoveCircleIcon />
          </IconButton>
          <Typography>{item.amount}</Typography>
          <IconButton onClick={onIncreaseItem}>
            <AddCircleIcon />
          </IconButton>
        </Box>
      </CardContent>
    </Card>
  );
};
