import { FC, useState } from "react";
import { Box } from "@mui/material";
import { getCartContent, saveCartContent } from "../../helpers/getCartContent";
import { Product, products } from "../../constants/constants";
import { ShoppingCartItem } from "./partials/ShoppingCartItem";

export const ShoppingCart: FC = () => {
  const [cartContent, setCartContent] = useState(getCartContent());

  const cartProducts: (Product & { amount: number })[] = Object.keys(
    cartContent
  ).map((id) => {
    const product = products.find((item) => item.id === id) as Product;

    return { ...product, amount: cartContent[id] };
  });

  const onDecreaseItem = (id: string) => {
    const newAmount = cartContent[id] - 1;

    const newCartContent = {
      ...cartContent,
      [id]: newAmount === 0 ? undefined : newAmount,
    };

    const parsedContent: {
      [x: string]: number;
    } = JSON.parse(JSON.stringify(newCartContent));

    setCartContent(parsedContent);
    saveCartContent(parsedContent);
  };

  const onIncreaseItem = (id: string) => {
    const newCartContent = { ...cartContent, [id]: cartContent[id] + 1 };
    setCartContent(newCartContent);
    saveCartContent(newCartContent);
  };

  return (
    <Box width="100%" maxWidth={700} padding={3}>
      <Box display="flex" flexDirection="column" gap={2} width="100%">
        {cartProducts.map((item) => (
          <ShoppingCartItem
            item={item}
            onDecreaseItem={() => onDecreaseItem(item.id)}
            onIncreaseItem={() => onIncreaseItem(item.id)}
          />
        ))}
      </Box>
    </Box>
  );
};
