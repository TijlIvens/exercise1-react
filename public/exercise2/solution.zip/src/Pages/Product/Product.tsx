import { FC, useState } from "react";
import { Box } from "@mui/material";
import { useParams } from "react-router-dom";
import { products } from "../../constants/constants";
import { ProductCard } from "./partials/ProductCart";
import { getCartContent, saveCartContent } from "../../helpers/getCartContent";
import { ProductNotFound } from "./partials/ProductNotFound";

export const Product: FC = () => {
  const [cartContent, setCartContent] = useState(getCartContent());

  const { id: productId } = useParams();

  const product = products.find((item) => item.id === productId);

  if (!product) {
    return <ProductNotFound />;
  }

  const amountInCart = cartContent[product.id] ?? 0;

  const onAddToCart = () => {
    const newCartContent = { ...cartContent, [product.id]: amountInCart + 1 };
    setCartContent(newCartContent);
    saveCartContent(newCartContent);
  };

  return (
    <Box width="100%" maxWidth={700}>
      <ProductCard
        product={product}
        onAddToCart={onAddToCart}
        amountInCart={amountInCart}
      />
    </Box>
  );
};
