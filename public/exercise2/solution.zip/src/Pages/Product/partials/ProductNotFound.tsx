import { FC } from "react";
import { Box, Typography } from "@mui/material";

export const ProductNotFound: FC = () => {
  return (
    <Box
      height="100%"
      width="100%"
      display="flex"
      alignItems="center"
      justifyContent="center"
    >
      <Typography>Product not found</Typography>
    </Box>
  );
};
