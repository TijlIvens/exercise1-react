import { FC } from "react";
import {
  Badge,
  Box,
  Button,
  Card,
  CardContent,
  CardMedia,
  Typography,
} from "@mui/material";
import AddShoppingCartIcon from "@mui/icons-material/AddShoppingCart";
import { Product } from "../../../constants/constants";

export interface ProductCardProps {
  product: Product;
  amountInCart: number;
  onAddToCart: () => void;
}

export const ProductCard: FC<ProductCardProps> = ({
  product,
  onAddToCart,
  amountInCart,
}) => {
  return (
    <Card sx={{ display: "flex", marginTop: 5 }}>
      <CardMedia
        component="img"
        sx={{ width: "50%" }}
        image={product.image}
        alt={product.name}
      />
      <CardContent>
        <Box display="flex" flexDirection="column" height="100%">
          <Box display="flex" flexDirection="column" flexGrow={1}>
            <Typography variant="h3">{product.name}</Typography>
            <Typography>{product.description}</Typography>
          </Box>
          <Box alignSelf="flex-end">
            <Button
              endIcon={
                <Badge
                  badgeContent={amountInCart}
                  color="warning"
                  invisible={!amountInCart}
                >
                  <AddShoppingCartIcon />
                </Badge>
              }
              onClick={onAddToCart}
            >
              Add to cart
            </Button>
          </Box>
        </Box>
      </CardContent>
    </Card>
  );
};
