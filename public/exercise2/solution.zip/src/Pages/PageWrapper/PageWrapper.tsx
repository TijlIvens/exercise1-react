import { FC } from "react";
import { Box, Button } from "@mui/material";
import { Link, Outlet } from "react-router-dom";
import { blue } from "@mui/material/colors";
import { ShoppingIcon } from "./partials/ShoppingIcon";
import { getCartContent } from "../../helpers/getCartContent";

export const PageWrapper: FC = () => {
  const cartContent = getCartContent();

  const numberOfItems = Object.values(cartContent).length;

  return (
    <Box
      height="100vh"
      display="flex"
      flexDirection="column"
      alignItems="center"
    >
      <Box
        width="100%"
        display="flex"
        justifyContent="center"
        bgcolor={blue[500]}
      >
        <Box
          width="100%"
          maxWidth={700}
          padding={2}
          display="flex"
          alignItems="center"
          justifyContent="space-between"
        >
          <Box display="flex" alignItems="center">
            <Link to="/">
              <Button sx={{ color: "white" }}>Home</Button>
            </Link>
            <Link to="/products" style={{ paddingLeft: 25 }}>
              <Button sx={{ color: "white" }}>Products</Button>
            </Link>
            <Link to="/inspiration">
              <Button sx={{ color: "white" }}>Inspiration</Button>
            </Link>
            <Link to="/about">
              <Button sx={{ color: "white" }}>About</Button>
            </Link>
          </Box>
          <Box>
            <ShoppingIcon numberOfItems={numberOfItems} />
          </Box>
        </Box>
      </Box>
      <Box
        flex={1}
        width="100%"
        display="flex"
        flexDirection="column"
        alignItems="center"
      >
        <Outlet />
      </Box>
    </Box>
  );
};
