import { FC } from "react";
import { Badge, IconButton } from "@mui/material";
import ShoppingCartIcon from "@mui/icons-material/ShoppingCart";
import { Link } from "react-router-dom";

export interface ShoppingIconProps {
  numberOfItems: number;
}

export const ShoppingIcon: FC<ShoppingIconProps> = ({ numberOfItems }) => {
  return (
    <Link to="/shopping-cart">
      <IconButton>
        <Badge
          badgeContent={numberOfItems}
          color="warning"
          invisible={!numberOfItems}
        >
          <ShoppingCartIcon sx={{ color: "white" }} />
        </Badge>
      </IconButton>
    </Link>
  );
};
