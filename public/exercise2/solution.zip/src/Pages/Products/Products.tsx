import { FC, useState } from "react";
import { Box } from "@mui/material";
import { ProductsList } from "./Partials/ProductsList";
import { categories, products } from "../../constants/constants";
import { CategoriesList } from "./Partials/CategoriesList";
import { SearchBox } from "./Partials/SearchBox";

export const Products: FC = () => {
  const [shownProducts, setShownProducts] = useState(products);
  const [selectedCategory, setSelectedCategory] = useState<string>();
  const [searchValue, setSearchValue] = useState("");

  const onSelectCategory = (category: string) => {
    if (selectedCategory === category) {
      setSelectedCategory(undefined);
      setShownProducts(products);
    } else {
      setSelectedCategory(category);
      setShownProducts(
        products.filter((product) => product.category === category)
      );
    }
  };

  const onSearch = () => {
    setSelectedCategory(undefined);
    setShownProducts(
      products.filter((product) =>
        product.name.toLowerCase().includes(searchValue?.toLowerCase())
      )
    );

    setSearchValue("");
  };

  return (
    <Box
      width="100%"
      maxWidth={900}
      display="flex"
      flexDirection="column"
      alignItems="center"
    >
      <SearchBox
        value={searchValue}
        setValue={setSearchValue}
        onSearch={onSearch}
      />
      <CategoriesList
        categories={categories}
        selectedCategory={selectedCategory}
        selectCategory={onSelectCategory}
      />
      <ProductsList products={shownProducts} />
    </Box>
  );
};
