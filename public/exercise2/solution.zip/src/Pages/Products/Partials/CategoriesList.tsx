import { FC } from "react";
import { Box, Button, Typography } from "@mui/material";

export interface CategoriesListProps {
  categories: string[];
  selectedCategory?: string;
  selectCategory: (category: string) => void;
}

export const CategoriesList: FC<CategoriesListProps> = ({
  categories,
  selectedCategory,
  selectCategory,
}) => {
  return (
    <Box
      display="flex"
      gap={1}
      width="100%"
      flexWrap="wrap"
      marginTop={3}
      alignItems="center"
    >
      <Typography>Category: </Typography>
      {categories.map((category) => (
        <Button
          key={category}
          color={
            selectedCategory
              ? selectedCategory === category
                ? "primary"
                : "inherit"
              : "primary"
          }
          variant="contained"
          onClick={() => selectCategory(category)}
        >
          {category}
        </Button>
      ))}
    </Box>
  );
};
