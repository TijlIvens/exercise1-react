import { FC } from "react";
import { Box, Button, TextField } from "@mui/material";

export interface SearchBoxProps {
  value: string;
  setValue: (value: string) => void;
  onSearch: () => void;
}

export const SearchBox: FC<SearchBoxProps> = ({
  value,
  setValue,
  onSearch,
}) => {
  return (
    <Box width="100%" margin={2} display="flex">
      <TextField
        value={value}
        onChange={(event) => setValue(event.target.value)}
        fullWidth
        placeholder="Search product"
      />
      <Button onClick={onSearch} sx={{ marginLeft: 2 }} variant="contained">
        Search
      </Button>
    </Box>
  );
};
