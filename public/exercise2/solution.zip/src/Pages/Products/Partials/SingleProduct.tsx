import { FC } from "react";
import {
  Button,
  Card,
  CardActions,
  CardContent,
  CardMedia,
  Typography,
} from "@mui/material";
import { Product } from "../../../constants/constants";
import { Link } from "react-router-dom";

export interface SingleProductProps {
  product: Product;
}

export const SingleProduct: FC<SingleProductProps> = ({ product }) => {
  return (
    <Card>
      <CardMedia sx={{ height: 140 }} image={product.image} />
      <CardContent>
        <Typography gutterBottom variant="h5" component="div">
          {product.name}
        </Typography>
        <Typography variant="body2" color="text.secondary">
          {product.description}
        </Typography>
      </CardContent>
      <CardActions>
        <Link to={`/product/${product.id}`}>
          <Button size="small">Details</Button>
        </Link>
      </CardActions>
    </Card>
  );
};
