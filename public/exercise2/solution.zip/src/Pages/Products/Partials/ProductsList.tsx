import { FC } from "react";
import { Grid } from "@mui/material";
import { Product } from "../../../constants/constants";
import { SingleProduct } from "./SingleProduct";

export interface ProductsListProps {
  products: Product[];
}

export const ProductsList: FC<ProductsListProps> = ({ products }) => {
  return (
    <Grid container spacing={2} margin={3}>
      {products.map((product) => (
        <Grid item xs={6} key={product.id}>
          <SingleProduct product={product} />
        </Grid>
      ))}
    </Grid>
  );
};
