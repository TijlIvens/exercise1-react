import { FC } from "react";
import { Box, Typography } from "@mui/material";

export const About: FC = () => {
  return (
    <Box width="100%" maxWidth={700} display="flex" justifyContent="center">
      <Typography paddingTop={5}>About this store</Typography>
    </Box>
  );
};
