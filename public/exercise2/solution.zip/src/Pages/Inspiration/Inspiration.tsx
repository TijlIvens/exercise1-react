import { FC } from "react";
import { Box, Typography } from "@mui/material";

export const Inspiration: FC = () => {
  return (
    <Box width="100%" maxWidth={700} display="flex" justifyContent="center">
      <Typography paddingTop={5}>Some inspiration for your home</Typography>
    </Box>
  );
};
