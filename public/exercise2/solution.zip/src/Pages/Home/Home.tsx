import { FC } from "react";
import { Box, Typography } from "@mui/material";
import { ShowReelPictures } from "./partials/ShowReelPictures";
import { showReelPictureUrls } from "../../constants/constants";

export const Home: FC = () => {
  return (
    <Box
      width="100%"
      maxWidth={700}
      display="flex"
      flexDirection="column"
      alignItems="center"
    >
      <Typography variant="h1" paddingTop={5}>
        The home store
      </Typography>
      <Typography variant="h5" paddingTop={2}>
        Live Laugh Love
      </Typography>
      <ShowReelPictures pictures={showReelPictureUrls} />
    </Box>
  );
};
