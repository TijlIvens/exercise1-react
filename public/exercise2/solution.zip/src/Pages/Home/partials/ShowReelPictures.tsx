import { FC } from "react";
import { Box } from "@mui/material";

export interface ShowReelPicturesProps {
  pictures: string[];
}

export const ShowReelPictures: FC<ShowReelPicturesProps> = ({ pictures }) => {
  return (
    <Box display="flex" justifyContent="space-between" paddingTop={3}>
      {pictures.map((url) => (
        <img style={{ aspectRatio: 1 / 1.7, width: "23%" }} src={url} />
      ))}
    </Box>
  );
};
