import { createBrowserRouter } from "react-router-dom";
import { Home } from "../Pages/Home/Home";
import { PageWrapper } from "../Pages/PageWrapper/PageWrapper";
import { Products } from "../Pages/Products/Products";
import { Inspiration } from "../Pages/Inspiration/Inspiration";
import { About } from "../Pages/About/About";
import { ShoppingCart } from "../Pages/ShoppingCart/ShoppingCart";
import { Product } from "../Pages/Product/Product";

export const router = createBrowserRouter([
  {
    path: "/",
    element: <PageWrapper />,
    children: [
      {
        path: "",
        element: <Home />,
      },
      {
        path: "products",
        element: <Products />,
      },
      {
        path: "inspiration",
        element: <Inspiration />,
      },
      {
        path: "about",
        element: <About />,
      },
      {
        path: "shopping-cart",
        element: <ShoppingCart />,
      },
      {
        path: "product/:id",
        element: <Product />,
      },
    ],
  },
]);
